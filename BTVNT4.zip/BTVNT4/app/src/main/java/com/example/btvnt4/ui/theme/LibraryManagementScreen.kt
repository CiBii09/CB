package com.example.btvnt4.ui

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btvnt4.StudentBorrow

@Composable
fun LibraryManagementScreen(borrowedList: MutableList<StudentBorrow>) {
    val mainColor = Color(0xFF1976D2)
    val lightBlue = Color(0xFFE3F2FD)

    var studentName by remember { mutableStateOf("") }
    val allBooks = listOf("Sách 01", "Sách 02", "Sách 03", "Sách 04", "Sách 05")
    val selectedBooks = remember { mutableStateListOf<String>() }

    val borrowedBooksSet = borrowedList.flatMap { it.books }.toSet()
    val existingStudent = borrowedList.find { it.name.equals(studentName.trim(), ignoreCase = true) }

        val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(lightBlue)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "📘 Hệ thống Quản lý Thư viện",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = mainColor
        )

        Spacer(Modifier.height(24.dp))

        // ------------------ Nhập tên sinh viên ------------------
        OutlinedTextField(
            value = studentName,
            onValueChange = { studentName = it },
            label = { Text("Tên sinh viên") },
            placeholder = { Text("Nhập tên sinh viên...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = mainColor,
                focusedLabelColor = mainColor,
                cursorColor = mainColor
            )
        )

        Spacer(Modifier.height(16.dp))

        // ------------------ Thông tin sách đã mượn ------------------
        if (studentName.isNotBlank()) {
            if (existingStudent != null && existingStudent.books.isNotEmpty()) {
                Text(
                    "📚 ${existingStudent.name} đã mượn:",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = mainColor
                )
                Spacer(Modifier.height(8.dp))
                existingStudent.books.forEach { book ->
                    Text("• $book", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                Text(
                    "Sinh viên này chưa mượn sách nào.",
                    color = Color.Gray,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        Divider(thickness = 1.dp, color = mainColor.copy(alpha = 0.3f))
        Spacer(Modifier.height(16.dp))

        // ------------------ Danh sách chọn sách ------------------
        Text(
            "Chọn sách để mượn:",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = mainColor
        )

        Spacer(Modifier.height(8.dp))

        allBooks.forEach { book ->
            val isBorrowedByOther =
                borrowedBooksSet.contains(book) && existingStudent?.books?.contains(book) != true

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Checkbox(
                    checked = selectedBooks.contains(book),
                    onCheckedChange = { isChecked ->
                        if (isChecked) selectedBooks.add(book)
                        else selectedBooks.remove(book)
                    },
                    enabled = !isBorrowedByOther,
                    colors = CheckboxDefaults.colors(
                        checkedColor = mainColor,
                        uncheckedColor = mainColor,
                        checkmarkColor = Color.White,
                        disabledCheckedColor = Color.Gray
                    ),
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                )

                val label = if (isBorrowedByOther) "$book (đã được mượn)" else book
                val color = if (isBorrowedByOther) Color.Gray else Color.Black
                Text(label, color = color, fontSize = 16.sp)
            }
        }

        Spacer(Modifier.height(16.dp))

        // ------------------ Nút thêm sinh viên mượn ------------------
        Button(
            onClick = {
                if (studentName.isNotBlank() && selectedBooks.isNotEmpty()) {
                    val existing = borrowedList.find { it.name.equals(studentName.trim(), ignoreCase = true) }
                    if (existing != null) {
                        selectedBooks.forEach { if (!existing.books.contains(it)) existing.books.add(it) }
                    } else {
                        borrowedList.add(StudentBorrow(studentName.trim(), selectedBooks.toMutableList()))
                    }
                    selectedBooks.clear()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = mainColor),
            modifier = Modifier.fillMaxWidth(),
            enabled = studentName.isNotBlank() && selectedBooks.isNotEmpty(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Thêm", fontWeight = FontWeight.Bold, color = Color.White)
        }

        Spacer(Modifier.height(24.dp))

        // ------------------ Tổng quan ------------------
        Text(
            "📖 Danh sách sinh viên và sách mượn:",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = mainColor
        )

        Spacer(Modifier.height(8.dp))

        borrowedList.forEach { s ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = s.name, fontWeight = FontWeight.Bold, color = mainColor)
                        Text(
                            text = "Sách: ${s.books.joinToString(", ")}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Black
                        )
                    }

                    IconButton(
                        onClick = { borrowedList.remove(s) },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.Red)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Xóa sinh viên")
                    }
                }
            }
        }

        // ------------------ Xác nhận sinh viên trả sách ------------------
        Spacer(Modifier.height(32.dp))
        Divider(thickness = 1.dp, color = mainColor.copy(alpha = 0.3f))
        Spacer(Modifier.height(16.dp))

        Text(
            text = "✅ Xác nhận sinh viên trả sách:",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = mainColor
        )

        var selectedReturnStudent by remember { mutableStateOf<String?>(null) }
        var showDialog by remember { mutableStateOf(false) }

        // Dropdown chọn sinh viên
        if (borrowedList.isNotEmpty()) {
            var expanded by remember { mutableStateOf(false) }

            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { expanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(selectedReturnStudent ?: "Chọn sinh viên cần trả sách")
                }

                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    borrowedList.forEach { student ->
                        DropdownMenuItem(
                            text = { Text(student.name) },
                            onClick = {
                                selectedReturnStudent = student.name
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = { if (selectedReturnStudent != null) showDialog = true },
                enabled = selectedReturnStudent != null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Xác nhận trả sách", color = Color.White, fontWeight = FontWeight.Bold)
            }

            // Hộp thoại xác nhận
            if (showDialog && selectedReturnStudent != null) {
                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    title = { Text("Xác nhận trả sách") },
                    text = { Text("Bạn có chắc rằng sinh viên '${selectedReturnStudent}' đã trả hết sách chưa?") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                borrowedList.removeIf { it.name.equals(selectedReturnStudent, ignoreCase = true) }
                                showDialog = false
                                selectedReturnStudent = null
                            }
                        ) {
                            Text("Xác nhận", color = mainColor, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDialog = false }) {
                            Text("Hủy")
                        }
                    }
                )
            }
        } else {
            Text("Hiện không có sinh viên nào để xác nhận trả sách.", color = Color.Gray)
        }
    }
}
