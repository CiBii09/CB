package com.example.btvnt4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.btvnt4.theme.BTVNT4Theme
import com.example.btvnt4.ui.*

data class StudentBorrow(
    val name: String,
    val books: MutableList<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BTVNT4Theme {
                var selectedTab by remember { mutableStateOf(0) }

                // ✅ Danh sách sinh viên & sách mượn (toàn cục)
                val borrowedList = remember { mutableStateListOf<StudentBorrow>() }

                Scaffold(
                    bottomBar = {
                        BottomNavBar(selectedTab) { selectedTab = it }
                    }
                ) { paddingValues ->
                    Surface(modifier = Modifier.padding(paddingValues)) {
                        when (selectedTab) {
                            0 -> LibraryManagementScreen(borrowedList)
                            1 -> BookListScreen()
                            2 -> StudentListScreen(borrowedList)
                        }
                    }
                }
            }
        }
    }
}
