package com.example.imreadyui.ui.theme

import androidx.compose.ui.graphics.Color

// 🔹 Màu cho chế độ sáng (Light)
val Purple40 = Color(0xFF1E88E5)     // xanh dương (primary)
val PurpleGrey40 = Color(0xFF90CAF9)  // xanh nhạt (secondary)
val Pink40 = Color(0xFFBBDEFB)        // xanh rất nhạt (tertiary)

// 🔹 Màu cho chế độ tối (Dark)
val Purple80 = Color(0xFF1565C0)
val PurpleGrey80 = Color(0xFF64B5F6)
val Pink80 = Color(0xFF42A5F5)

