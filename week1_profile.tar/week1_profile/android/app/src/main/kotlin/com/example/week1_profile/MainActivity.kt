package com.example.week1_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
