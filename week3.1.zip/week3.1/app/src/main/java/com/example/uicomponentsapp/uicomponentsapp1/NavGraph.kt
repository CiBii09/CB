package com.example.uicomponentsapp

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun AppNavHost() {
    val navController: NavHostController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "ready_screen"
    ) {
        composable("ready_screen") { ReadyScreen(navController) }
        composable("components_list") { ComponentsListScreen(navController) }
        composable("text_detail") { TextDetailScreen(navController) }
    }
}
