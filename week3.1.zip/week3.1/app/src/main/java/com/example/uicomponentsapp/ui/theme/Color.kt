package com.example.uicomponentsapp.ui.theme

import androidx.compose.ui.graphics.Color

// 🔹 Màu chủ đạo xanh như slide
val Purple40 = Color(0xFF1E88E5)
val PurpleGrey40 = Color(0xFFB0BEC5)
val Pink40 = Color(0xFFF48FB1)

// 🔹 Dark mode (nếu có)
val Purple80 = Color(0xFF90CAF9)
val PurpleGrey80 = Color(0xFFCFD8DC)
val Pink80 = Color(0xFFF8BBD0)
