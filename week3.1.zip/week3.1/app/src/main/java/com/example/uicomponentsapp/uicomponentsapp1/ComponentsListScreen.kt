package com.example.uicomponentsapp

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun ComponentsListScreen(navController: NavController) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("UI Components List")

        Spacer(modifier = Modifier.height(16.dp))

        val items = listOf("Text", "Image", "TextField", "PasswordField", "Column", "Row")

        items.forEach { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable {
                        if (item == "Text") navController.navigate("text_detail")
                    }
            ) {
                Text(
                    text = item,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}
